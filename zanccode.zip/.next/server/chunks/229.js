"use strict";
exports.id = 229;
exports.ids = [229];
exports.modules = {

/***/ 2229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Articles)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/ImageCustom.js
var ImageCustom = __webpack_require__(6865);
;// CONCATENATED MODULE: ./components/CardArticle.js



const CardArticle = ({ article  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: `/article/${article.attributes.slug}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "bg-transparent rounded-md max-w-[400px] min-h-[270px] p-5 hover:bg-gray-900 transition-all duration-75",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "rounded-md object-cover",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(ImageCustom/* default */.Z, {
                        width: 400,
                        height: 100,
                        styles: "rounded-md object-cover h-32",
                        gambar: article.attributes.image
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-sm font-normal lg:font-medium lg:text-base text-indigo-300 mt-2 mb-1",
                            id: "category",
                            children: article.attributes.category.data.attributes.name
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-xl md:text-2xl text-transparent font-bold capitalize bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-600 bg-clip-text",
                            id: "title",
                            children: article.attributes.title
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_CardArticle = (CardArticle);

;// CONCATENATED MODULE: ./components/Articles.js


const Articles = ({ articles  })=>{
    const sortedArticle = articles.sort((a, b)=>new Date(b.attributes.createdAt) - new Date(a.attributes.createdAt));
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "mt-10 flex flex-wrap justify-center gap-2",
        children: sortedArticle.map((article)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx(components_CardArticle, {
                article: article
            }, `article__${article.attributes.slug}`);
        })
    });
};
/* harmony default export */ const components_Articles = (Articles);


/***/ })

};
;